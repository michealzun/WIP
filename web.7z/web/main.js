//scrolling
var sounds = false;
var menuanchors = document.querySelectorAll(".topnav_listitem");
menuanchors.forEach( e => {
    e.addEventListener("click",function(){smoothScroll(e.dataset.menuanchor);});
});
function smoothScroll(target){
    console.log(target) 
    document.querySelector(target).scrollIntoView({behavior:'smooth'});
}

//mouse position
var position
document.addEventListener('mousemove', e => {
    document.elementFromPoint(e.clientX, e.clientY) 
}, {passive: true})

//scroll
window.onscroll = scrollFunction;
function scrollFunction() {
    console.log("aaa");
}




function music() {
    sounds = !sounds;
    if(sounds){
        document.querySelector("#music_switch").src= "./images/unmute.png";
        navBarHide()
    }else{
        document.querySelector("#music_switch").src= "./images/mute.png";
        navBarShow()
    }
}

function navBarHide(){
    document.querySelector("#topnav").style.top = "100px";
}

function navBarShow(){
    document.querySelector("#topnav").style.top = "0px";
}

